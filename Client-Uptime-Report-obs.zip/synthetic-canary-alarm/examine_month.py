import boto3
from datetime import datetime, timedelta

# Initialize a session using Amazon CloudWatch and Synthetics
cloudwatch_client = boto3.client('cloudwatch', region_name='us-east-1')  # Specify your region
synthetics_client = boto3.client('synthetics', region_name='us-east-1')  # Specify your region

# Define the parameters
namespace = 'CloudWatchSynthetics'
metric_name = 'SuccessPercent'
statistic = 'Minimum'
canary_names = [
    "sandbox-sandbox-atlas-promerit-prod-sc",
    "sandbox-sandbox-atlas-promerit-sit-sc",
    "sandbox-sandbox-atlas-promerit-sit2-sc",
    "sandbox-sandbox-bmo-promerit-prod-sc",
    "sandbox-sandbox-bmo-promerit-sit-sc",
    "sandbox-sandbox-citi-embtrust-sit-sc",
    "sandbox-sandbox-demo-promerit-sit-sc",
    "sandbox-sandbox-jpmc-embtrust-prod-sc",
    "sandbox-sandbox-jpmc-embtrust-sit-sc",
    "sandbox-sandbox-mizu-promerit-prod-sc",
    "sandbox-sandbox-mizu-promerit-sit-sc",
    "sandbox-sandbox-pnc-promerit-sit-sc",
    "sandbox-sandbox-truist-embtrust-prod-sc",
    "sandbox-sandbox-truist-embtrust-sit-sc",
    "sandbox-sandbox-was-promerit-sit-sc"
]

# Define the time range for the query
start_string = "2025-01-01T00:00:00Z"
start_time = datetime.strptime(start_string, "%Y-%m-%dT%H:%M:%SZ")

end_string = "2025-01-31T23:59:59Z"
end_time = datetime.strptime(end_string, "%Y-%m-%dT%H:%M:%SZ")

# Function to get metric data
def get_metric_data(client, namespace, metric_name, statistic, start_time, end_time, dimensions):
    
    response = client.get_metric_statistics(
        Namespace=namespace,
        MetricName=metric_name,
        StartTime=start_time,
        EndTime=end_time,
        Period=60,
        Statistics=[statistic],
        Dimensions=dimensions
    )
    return response

# Function to get environment variables for a canary
def get_canary_URL_tag(client, canary_name):
    response = client.describe_canaries(Names=[canary_name])
    thee_URL_tag = response["Canaries"][0]["Tags"]["URL"]
    return thee_URL_tag

# Function to find periods with zero SuccessPercent for five consecutive data points or more
def find_zero_success_periods(datapoints):
    zero_periods = []
    current_period_start = None
    zero_count = 0

    # print(f"  datapoints value is: {datapoints}")
    consecutive_data_points_count = 4
    for datapoint in sorted(datapoints, key=lambda x: x['Timestamp']):
        if datapoint['Minimum'] == 0:
            if zero_count == 0:
                current_period_start = datapoint['Timestamp']
                # To see each data point when SuccessPercent is ZERO, uncomment this next line:
                # print(f"      Timestamp of suspect data point with SuccessPercent == zero (0) is: {datapoint['Timestamp']}")
                # print(f"      datapoint is: {datapoint}")
            zero_count += 1
        else:
            if zero_count >= consecutive_data_points_count:
                zero_periods.append((current_period_start, datapoint['Timestamp'] - timedelta(minutes=1)))
            zero_count = 0

    if zero_count >= consecutive_data_points_count:
        zero_periods.append((current_period_start, datapoint['Timestamp']))

    return zero_periods

# Function to process each day within the specified date range
def process_daily_metrics(canary_name, start_date, end_date):
    current_date = start_date
    while current_date <= end_date:
        next_date = current_date + timedelta(days=1)
        # next_date = current_date + timedelta(hours=1)
        dimensions = [{"Name": "CanaryName", "Value": canary_name}]
        metric_response = get_metric_data(cloudwatch_client, namespace, metric_name, statistic, current_date, next_date, dimensions)
        
        # print(f"  Metrics for {canary_name} on {current_date.date()}: ")
        metric_header = f"Metrics for '{canary_name}' on {current_date.date()}"
        
        zero_success_periods = find_zero_success_periods(metric_response['Datapoints'])
        
        if zero_success_periods:
            # print(f"    {metric_header} Periods with zero SuccessPercent for five consecutive data points or more:")
            print(f"    {metric_header} had suspected down time in this range:")
            for period in zero_success_periods:
                # print("       Detail ^ above.")
                print(f"      Start: {period[0]}, End: {period[1]}")
        else:
            # print("    No periods with zero SuccessPercent for five consecutive data points or more found.")
            print(f"    {metric_header}: Uptime 100%.")
        current_date = next_date

# Query for each canary and process daily metrics
for canary_name in canary_names:
    thee_URL = get_canary_URL_tag(synthetics_client, canary_name)
    print("=======================================================\n")
    print("\n")
    print("\n")
    print(f"Processing metrics for Synthetic Canary '{canary_name}'")
    print(f" for URL: {thee_URL}\n")
    
    process_daily_metrics(canary_name, start_time, end_time)
